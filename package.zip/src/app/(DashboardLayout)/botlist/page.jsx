'use client'

import Botlist from './Botlist';

export default function Page() {
  return <><Botlist/></>;
}

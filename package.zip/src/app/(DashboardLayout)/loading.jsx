"use client"

import { PageLoader } from "../common/PageLoader";

const Loading = () => {
    return (
        <div><PageLoader></PageLoader></div>
    )
}

export default Loading;
'use client'

import { Box, InputLabel, MenuItem, FormControl, Select, FormHelperText } from '@mui/material';
import { useEffect, useState } from 'react';

export default function HeightPicker({
  label = "Height",
  required = true,
  error = false,
}) {
  const [feet, setFeet] = useState(5); // Default feet
  const [inches, setInches] = useState(0); // Default inches
  const [height, setHeight] = useState("5'0''"); // Default height string

  const handleFeetChange = (event) => {
    setFeet(event.target.value);
  };

  const handleInchesChange = (event) => {
    setInches(event.target.value);
  };

  useEffect (() => {
    // Update the height string when feet or inches change
    setHeight(`${feet}'${inches}''`);
  }, [feet, inches]);

  return (
    <Box sx={{ display: 'flex', alignItems: 'center' }}>
              <InputLabel         required={required}
 sx={{marginRight: '15px',          '& .MuiFormLabel-asterisk': { color: 'red' },
}}>Height</InputLabel>

      <FormControl sx={{ marginRight: 2 }} required={required} error={error}>


        <InputLabel>Feet</InputLabel>
        <Select
          value={feet}
          onChange={handleFeetChange}
          label="Feet"
        >
          {[...Array(10).keys()].map((i) => (
            <MenuItem key={i} value={i + 3}>
              {i + 3}
            </MenuItem>
          ))}
        </Select>
        {error && <FormHelperText>Height is required</FormHelperText>}
      </FormControl>

      <FormControl required={required} error={error}>
        <InputLabel>Inches</InputLabel>
        <Select
          value={inches}
          onChange={handleInchesChange}
          label="Inches"
        >
          {[...Array(12).keys()].map((i) => (
            <MenuItem key={i} value={i}>
              {i}
            </MenuItem>
          ))}
        </Select>
        {error && <FormHelperText>Height is required</FormHelperText>}
      </FormControl>
    </Box>
  );
}

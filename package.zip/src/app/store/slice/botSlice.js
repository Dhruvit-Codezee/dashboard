import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axios from "axios";
import toast from "react-hot-toast";

const initialState = {
    botLoading: false,
    allBotList: [],
};

export const getAllDataList = createAsyncThunk(
    'https://api.rosify.in/api/avtars-info/',
    async ({ rejectWithValue }) => {
        try {
            const response = await axios.get(`https://api.rosify.in/api/avtars-info/`);
            const { data, message, status_code } = response.data;

            if (status_code === 200) {

                return data;
            } else {
                // toast.error(message)
                return false;
            }
        } catch (e) {
            toast.error(e);
            return false;
        }
    }
);

export const botSlice = createSlice({
    name: "bot",
    initialState,
    reducers: {
        setBotLoading: (state, action) => {
            state.botLoading = action.payload;
        },
        setAllBotList: (state, action) => {
            state.allBotList = action.payload;
        },

    },
    extraReducers: (builder) => {
        builder
            .addCase(getAllDataList.pending, (state) => {
                state.botLoading = true;
            })
            .addCase(getAllDataList.fulfilled, (state, action) => {
                state.botLoading = false;
                state.allBotList = action.payload;
            })
            .addCase(getAllDataList.rejected, (state, action) => {
                state.botLoading = false;
            })

    },
});

export const {
    setBotLoading,
    setAllBotList,

} = botSlice.actions;

export default botSlice.reducer;

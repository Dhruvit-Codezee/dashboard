import { combineReducers, configureStore } from "@reduxjs/toolkit";
import bot from "./slice/botSlice";

const reducers = combineReducers({
  bot,
});

const store = configureStore({
  reducer: reducers
});

export { store };

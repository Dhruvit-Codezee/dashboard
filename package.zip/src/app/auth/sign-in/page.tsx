import Login from "@/app/common/Login";

export default function Page() {
  return (
    <div>
      <Login/>
    </div>
  );
}

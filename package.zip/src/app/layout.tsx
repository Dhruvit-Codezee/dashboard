"use client";

import { usePathname } from "next/navigation";
import axios from "axios";
import { baselightTheme } from "@/utils/theme/DefaultColors";
import type { PropsWithChildren } from "react";
import { ThemeProvider } from "@mui/material/styles";
import { SessionLoader } from "@/provider/SessionLoader";
import { AuthSessionProvider } from "@/provider/AuthSessionProvider";
import { PublicPageLayout } from "@/layouts/PublicPageLayout";
import { PrivatePageLayout } from "@/layouts/PrivatePageLayout";
import { Providers } from "./store/providers";
import ToastElement from "./common/ToastElement";


export default function RootLayout({ children }: Readonly<PropsWithChildren>) {
  const currentPathname = usePathname();

  const authPage = currentPathname.startsWith("/auth");

  console.log('authPage', authPage)

  axios.defaults.baseURL = process.env.NEXT_PUBLIC_API_SERVER;

  return (
    <html lang="en">
      <body className="antialiased">
        <AuthSessionProvider>
          <SessionLoader>
            <Providers>
            <ThemeProvider theme={baselightTheme}>
              {authPage ? (
                <PublicPageLayout>{children}</PublicPageLayout>
              ) : (
                <PrivatePageLayout>{children}</PrivatePageLayout>
              )}
                          <ToastElement />

            </ThemeProvider>         
            </Providers>   
          </SessionLoader>
        </AuthSessionProvider>
      </body>
    </html>
  );
}

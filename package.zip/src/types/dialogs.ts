import type { ReactNode } from "react";

export type DialogTypes = "add" | "edit" | "delete" | "view";

export type DialogRenderer = { [key in DialogTypes]?: ReactNode };

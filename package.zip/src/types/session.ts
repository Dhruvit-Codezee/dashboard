export type User = {
  id: string;
  email: string;
  avatar: string | null;
  token: string;
  role_level: number;
};

"use client";

import { PageLoader } from "@/app/common/PageLoader";
import { Box } from "@mui/material";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import type { PropsWithChildren } from "react";
import { useEffect } from "react";

export function PublicPageLayout({ children }: Readonly<PropsWithChildren>) {
  const { status } = useSession();
  

  const router = useRouter();

  useEffect(() => {
    if (status === "authenticated") {
      router.push("/");
    }
  }, [status, router]);

  if (status === "authenticated") {
    return <PageLoader />;
  }

  return (
    <Box
      component="main"
      sx={{
        flexGrow: 1,
        // background: (theme) => theme.palette.app.color.slate[800],
      }}
    >
      {children}
    </Box>
  );
}

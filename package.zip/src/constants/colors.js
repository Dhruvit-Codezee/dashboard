const COLORS = {
    MIRAGE_600: '#3C4858',
  };
  
  export default COLORS;
  
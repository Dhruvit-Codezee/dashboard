"use client";

import { PageLoader } from "@/app/common/PageLoader";
import { useSession } from "next-auth/react";
import type { PropsWithChildren } from "react";

export const SessionLoader = ({ children }: PropsWithChildren) => {
  const { status } = useSession();

  if (status === "loading") {
    return <PageLoader />;
  }

  return children;
};
